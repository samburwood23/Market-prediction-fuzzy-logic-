"""
system.py
---------

This module implements the ``ShareholderValueOptimizer`` class.  The
optimizer combines metrics from trading performance, marketing
performance, risk management and market share growth into a single
fuzzy score representing overall shareholder value.  It uses a
Mamdani inference system to evaluate qualitative rules and then
computes additional numeric metrics such as total value impact and
provides strategic recommendations.

The scoring is designed to be interpretable: the highest scores
result from high returns and ROI coupled with low risk and strong
market expansion.  Low scores indicate weaknesses in one or more
areas that should be addressed.
"""

from __future__ import annotations

from typing import Dict, List

from ..core.fuzzy_variable import FuzzyVariable, FuzzySet
from ..core.fuzzy_rule import FuzzyRule
from ..core.fuzzy_system import FuzzyInferenceSystem
from ..core import membership_functions as mf


class ShareholderValueOptimizer:
    """Compute an overall shareholder value score and recommendations.

    Inputs:
      - ``trading_returns``: annualised return from trading strategies (percentage)
      - ``marketing_roi``: return on marketing investment (ratio)
      - ``risk_level``: risk metric (0–100); higher values represent
        greater risk
      - ``market_share_growth``: growth in market share (percentage)

    The output ``shareholder_value_score`` is scaled from 0 to 100.
    In addition to the score the optimizer returns a list of
    recommendations to enhance shareholder value.
    """

    def __init__(self) -> None:
        # Input: trading returns (0–100%)
        self.trading_returns = FuzzyVariable("trading_returns", (0.0, 100.0))
        self.trading_returns.add_set("low", FuzzySet(mf.triangular(0.0, 5.0, 20.0), label="low"))
        self.trading_returns.add_set("medium", FuzzySet(mf.triangular(10.0, 30.0, 50.0), label="medium"))
        self.trading_returns.add_set("high", FuzzySet(mf.triangular(40.0, 70.0, 100.0), label="high"))

        # Input: marketing ROI (0–5)
        self.marketing_roi = FuzzyVariable("marketing_roi", (0.0, 5.0))
        self.marketing_roi.add_set("low", FuzzySet(mf.triangular(0.0, 0.5, 1.5), label="low"))
        self.marketing_roi.add_set("medium", FuzzySet(mf.triangular(1.0, 2.0, 3.5), label="medium"))
        self.marketing_roi.add_set("high", FuzzySet(mf.triangular(3.0, 4.0, 5.0), label="high"))

        # Input: risk level (0–100)
        self.risk_level = FuzzyVariable("risk_level", (0.0, 100.0))
        self.risk_level.add_set("low", FuzzySet(mf.triangular(0.0, 15.0, 35.0), label="low"))
        self.risk_level.add_set("medium", FuzzySet(mf.triangular(30.0, 50.0, 70.0), label="medium"))
        self.risk_level.add_set("high", FuzzySet(mf.triangular(60.0, 80.0, 100.0), label="high"))

        # Input: market share growth (0–20%)
        self.market_share = FuzzyVariable("market_share_growth", (0.0, 20.0))
        self.market_share.add_set("low", FuzzySet(mf.triangular(0.0, 2.0, 6.0), label="low"))
        self.market_share.add_set("medium", FuzzySet(mf.triangular(5.0, 8.0, 12.0), label="medium"))
        self.market_share.add_set("high", FuzzySet(mf.triangular(10.0, 15.0, 20.0), label="high"))

        # Output: shareholder value score (0–100)
        self.value = FuzzyVariable("shareholder_value_score", (0.0, 100.0))
        self.value.add_set("poor", FuzzySet(mf.triangular(0.0, 15.0, 35.0), label="poor"))
        self.value.add_set("moderate", FuzzySet(mf.triangular(30.0, 45.0, 60.0), label="moderate"))
        self.value.add_set("good", FuzzySet(mf.triangular(55.0, 70.0, 85.0), label="good"))
        self.value.add_set("excellent", FuzzySet(mf.triangular(80.0, 90.0, 100.0), label="excellent"))

        # Define rules
        rules: List[FuzzyRule] = []
        # Excellent when returns high, ROI high, risk low and market share growth high
        rules.append(
            FuzzyRule(
                antecedents=[
                    (self.trading_returns, "high"),
                    (self.marketing_roi, "high"),
                    (self.risk_level, "low"),
                    (self.market_share, "high"),
                ],
                consequent=(self.value, "excellent"),
            )
        )
        # Good when returns high and ROI medium, risk medium
        rules.append(
            FuzzyRule(
                antecedents=[
                    (self.trading_returns, "high"),
                    (self.marketing_roi, "medium"),
                    (self.risk_level, "medium"),
                ],
                consequent=(self.value, "good"),
            )
        )
        # Good when returns medium, ROI high, risk low
        rules.append(
            FuzzyRule(
                antecedents=[
                    (self.trading_returns, "medium"),
                    (self.marketing_roi, "high"),
                    (self.risk_level, "low"),
                ],
                consequent=(self.value, "good"),
            )
        )
        # Moderate when returns medium, ROI medium and risk medium
        rules.append(
            FuzzyRule(
                antecedents=[
                    (self.trading_returns, "medium"),
                    (self.marketing_roi, "medium"),
                    (self.risk_level, "medium"),
                ],
                consequent=(self.value, "moderate"),
            )
        )
        # Poor when returns low or ROI low or risk high
        rules.append(
            FuzzyRule(
                antecedents=[(self.trading_returns, "low"), (self.marketing_roi, "low")],
                consequent=(self.value, "poor"),
            )
        )
        rules.append(
            FuzzyRule(
                antecedents=[(self.risk_level, "high"), (self.trading_returns, "medium")],
                consequent=(self.value, "poor"),
            )
        )
        rules.append(
            FuzzyRule(
                antecedents=[(self.risk_level, "high"), (self.marketing_roi, "medium")],
                consequent=(self.value, "poor"),
            )
        )
        # Moderate when returns low but ROI high and risk low
        rules.append(
            FuzzyRule(
                antecedents=[
                    (self.trading_returns, "low"),
                    (self.marketing_roi, "high"),
                    (self.risk_level, "low"),
                ],
                consequent=(self.value, "moderate"),
            )
        )
        # Good when returns high and risk low regardless of ROI if market share growth medium/high
        rules.append(
            FuzzyRule(
                antecedents=[(self.trading_returns, "high"), (self.risk_level, "low"), (self.market_share, "medium")],
                consequent=(self.value, "good"),
            )
        )
        rules.append(
            FuzzyRule(
                antecedents=[(self.trading_returns, "high"), (self.risk_level, "low"), (self.market_share, "high")],
                consequent=(self.value, "excellent"),
                weight=0.9,
            )
        )

        self.system = FuzzyInferenceSystem(
            input_variables=[self.trading_returns, self.marketing_roi, self.risk_level, self.market_share],
            output_variable=self.value,
            rules=rules,
            universe_resolution=300,
        )

    def calculate_value(
        self,
        *,
        trading_returns: float,
        marketing_roi: float,
        risk_level: float,
        market_share_growth: float,
    ) -> Dict[str, object]:
        """Compute overall shareholder value and recommendations.

        Parameters
        ----------
        trading_returns : float
            Annualised trading return percentage (e.g. 15.0 for 15%).
        marketing_roi : float
            Marketing return on investment (e.g. 2.5 for 250%).
        risk_level : float
            Risk level on a scale of 0 to 100, where higher numbers
            indicate greater risk.
        market_share_growth : float
            Percentage growth in market share (e.g. 5.0 for 5%).

        Returns
        -------
        Dict[str, object]
            A dictionary containing the ``shareholder_value_score`` (0–100),
            ``total_value_impact_percent`` and a list of ``recommendations``.
        """
        inputs = {
            "trading_returns": float(trading_returns),
            "marketing_roi": float(marketing_roi),
            "risk_level": float(risk_level),
            "market_share_growth": float(market_share_growth),
        }
        crisp_value = self.system.evaluate(inputs)
        # Determine fuzzy label for the crisp value (not necessary but helpful for recommendations)
        memberships = {name: fs.membership(crisp_value) for name, fs in self.value.sets.items()}
        best_label = max(memberships.items(), key=lambda item: item[1])[0]

        # Compute a total value impact metric using a weighted linear model
        # Each component is normalised to [0, 1] and weighted
        tr_norm = max(0.0, min(trading_returns / 100.0, 1.0))
        roi_norm = max(0.0, min(marketing_roi / 5.0, 1.0))
        risk_norm = max(0.0, min(risk_level / 100.0, 1.0))
        ms_norm = max(0.0, min(market_share_growth / 20.0, 1.0))
        total_value_impact = (0.4 * tr_norm + 0.3 * roi_norm + 0.2 * ms_norm - 0.3 * risk_norm)
        # Express as percentage for readability
        total_value_impact_percent = total_value_impact * 100.0

        # Build recommendations
        recommendations: List[str] = []
        # Trading performance analysis
        if memberships["poor"] > 0.4 or trading_returns < 10.0:
            recommendations.append("Improve trading performance through better strategy and risk management.")
        elif memberships["excellent"] > 0.4 and trading_returns > 20.0:
            recommendations.append("Maintain high trading performance and consider scaling positions judiciously.")

        # Marketing ROI analysis
        if marketing_roi < 1.0:
            recommendations.append("Allocate marketing budget towards more effective channels to boost ROI.")
        elif marketing_roi > 3.0 and memberships["excellent"] > 0.3:
            recommendations.append("Continue investing in high‑performing marketing initiatives.")

        # Risk analysis
        if risk_level > 60.0:
            recommendations.append("Reduce overall risk through diversification or hedging strategies.")
        elif risk_level < 20.0 and memberships["excellent"] > 0.3:
            recommendations.append("Risk is well managed; explore selective opportunities for growth.")

        # Market share growth analysis
        if market_share_growth < 5.0:
            recommendations.append("Explore new markets or improve competitive positioning to grow market share.")
        elif market_share_growth > 10.0 and memberships["excellent"] > 0.3:
            recommendations.append("Leverage strong market share growth to negotiate better terms with partners.")

        return {
            "shareholder_value_score": crisp_value,
            "total_value_impact_percent": total_value_impact_percent,
            "recommendations": recommendations,
        }
