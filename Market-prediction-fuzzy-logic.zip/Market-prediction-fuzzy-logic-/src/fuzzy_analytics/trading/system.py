"""
system.py
---------

This module contains the ``TradingFuzzySystem`` class for generating
trading signals using fuzzy logic and a ``TradingIndicators`` helper
class that delegates to the functions in :mod:`fuzzy_analytics.indicators`.

The fuzzy trading system models the relationship between three input
features—RSI, MACD histogram and volatility—and a single output
variable representing a recommended trading action.  The output
domain is scaled between 0 and 1, where lower values correspond to
``strong_sell`` and higher values correspond to ``strong_buy``.  A
mapping from the crisp output to discrete action labels with
confidence scores is provided.
"""

from __future__ import annotations

from typing import Dict, Tuple

from ..core.fuzzy_variable import FuzzyVariable, FuzzySet
from ..core.fuzzy_rule import FuzzyRule
from ..core.fuzzy_system import FuzzyInferenceSystem
from ..core import membership_functions as mf
from ..indicators import calculate_rsi, calculate_macd, calculate_volatility, calculate_bollinger_bands


class TradingFuzzySystem:
    """A fuzzy inference system for trading signals.

    This system uses RSI, MACD histogram and volatility to infer a
    recommended trading action.  The evaluation returns a discrete
    action (one of ``strong_sell``, ``sell``, ``hold``, ``buy`` or
    ``strong_buy``) along with a confidence score in [0, 1].
    """

    def __init__(self) -> None:
        # Define input variables and their fuzzy sets
        # RSI ranges from 0 to 100
        self.rsi = FuzzyVariable("rsi", (0.0, 100.0))
        self.rsi.add_set("oversold", FuzzySet(mf.triangular(0.0, 10.0, 30.0), label="oversold"))
        self.rsi.add_set("neutral", FuzzySet(mf.triangular(20.0, 50.0, 80.0), label="neutral"))
        self.rsi.add_set("overbought", FuzzySet(mf.triangular(70.0, 90.0, 100.0), label="overbought"))

        # MACD histogram ranges approximately between -1 and 1 in most cases
        self.macd_histogram = FuzzyVariable("macd_histogram", (-1.0, 1.0))
        self.macd_histogram.add_set("negative", FuzzySet(mf.triangular(-1.0, -0.5, 0.0), label="negative"))
        self.macd_histogram.add_set("zero", FuzzySet(mf.triangular(-0.25, 0.0, 0.25), label="zero"))
        self.macd_histogram.add_set("positive", FuzzySet(mf.triangular(0.0, 0.5, 1.0), label="positive"))

        # Volatility ranges from 0 to perhaps 1 (0% to 100%)
        self.volatility = FuzzyVariable("volatility", (0.0, 1.0))
        self.volatility.add_set("low", FuzzySet(mf.triangular(0.0, 0.1, 0.3), label="low"))
        self.volatility.add_set("medium", FuzzySet(mf.triangular(0.2, 0.4, 0.6), label="medium"))
        self.volatility.add_set("high", FuzzySet(mf.triangular(0.5, 0.7, 1.0), label="high"))

        # Define output variable representing the trading action on domain [0, 1]
        self.action = FuzzyVariable("action", (0.0, 1.0))
        # Use trapezoidal shapes so the extremities saturate
        self.action.add_set(
            "strong_sell",
            FuzzySet(mf.trapezoidal(0.0, 0.0, 0.1, 0.2), label="strong_sell"),
        )
        self.action.add_set(
            "sell",
            FuzzySet(mf.triangular(0.15, 0.25, 0.4), label="sell"),
        )
        self.action.add_set(
            "hold",
            FuzzySet(mf.triangular(0.35, 0.5, 0.65), label="hold"),
        )
        self.action.add_set(
            "buy",
            FuzzySet(mf.triangular(0.6, 0.75, 0.85), label="buy"),
        )
        self.action.add_set(
            "strong_buy",
            FuzzySet(mf.trapezoidal(0.8, 0.9, 1.0, 1.0), label="strong_buy"),
        )

        # Construct rules
        rules = []
        # Oversold & positive histogram -> strong buy
        rules.append(
            FuzzyRule(
                antecedents=[(self.rsi, "oversold"), (self.macd_histogram, "positive")],
                consequent=(self.action, "strong_buy"),
            )
        )
        # Oversold & zero histogram -> buy
        rules.append(
            FuzzyRule(
                antecedents=[(self.rsi, "oversold"), (self.macd_histogram, "zero")],
                consequent=(self.action, "buy"),
            )
        )
        # Oversold & negative histogram -> hold (wait for reversal)
        rules.append(
            FuzzyRule(
                antecedents=[(self.rsi, "oversold"), (self.macd_histogram, "negative")],
                consequent=(self.action, "hold"),
            )
        )
        # Neutral RSI & positive histogram -> buy
        rules.append(
            FuzzyRule(
                antecedents=[(self.rsi, "neutral"), (self.macd_histogram, "positive")],
                consequent=(self.action, "buy"),
            )
        )
        # Neutral RSI & zero histogram -> hold
        rules.append(
            FuzzyRule(
                antecedents=[(self.rsi, "neutral"), (self.macd_histogram, "zero")],
                consequent=(self.action, "hold"),
            )
        )
        # Neutral RSI & negative histogram -> sell
        rules.append(
            FuzzyRule(
                antecedents=[(self.rsi, "neutral"), (self.macd_histogram, "negative")],
                consequent=(self.action, "sell"),
            )
        )
        # Overbought & negative histogram -> strong sell
        rules.append(
            FuzzyRule(
                antecedents=[(self.rsi, "overbought"), (self.macd_histogram, "negative")],
                consequent=(self.action, "strong_sell"),
            )
        )
        # Overbought & zero histogram -> sell
        rules.append(
            FuzzyRule(
                antecedents=[(self.rsi, "overbought"), (self.macd_histogram, "zero")],
                consequent=(self.action, "sell"),
            )
        )
        # Overbought & positive histogram -> hold
        rules.append(
            FuzzyRule(
                antecedents=[(self.rsi, "overbought"), (self.macd_histogram, "positive")],
                consequent=(self.action, "hold"),
            )
        )

        # Additional rule to account for high volatility: if volatility is high, reduce aggressiveness
        # When volatility is high and histogram positive, prefer hold instead of buy
        rules.append(
            FuzzyRule(
                antecedents=[(self.volatility, "high"), (self.macd_histogram, "positive")],
                consequent=(self.action, "hold"),
                weight=0.8,
            )
        )
        # When volatility is high and histogram negative, increase selling strength
        rules.append(
            FuzzyRule(
                antecedents=[(self.volatility, "high"), (self.macd_histogram, "negative")],
                consequent=(self.action, "strong_sell"),
                weight=0.8,
            )
        )
        # When volatility is low and RSI oversold, emphasise strong buy
        rules.append(
            FuzzyRule(
                antecedents=[(self.volatility, "low"), (self.rsi, "oversold")],
                consequent=(self.action, "strong_buy"),
                weight=0.8,
            )
        )

        self.system = FuzzyInferenceSystem(
            input_variables=[self.rsi, self.macd_histogram, self.volatility],
            output_variable=self.action,
            rules=rules,
            universe_resolution=200,
        )

    def evaluate(self, *, rsi: float, macd_histogram: float, volatility: float) -> Dict[str, float]:
        """Evaluate the fuzzy trading system and return a discrete action.

        Parameters
        ----------
        rsi : float
            Current RSI value (0–100).
        macd_histogram : float
            Current MACD histogram value.
        volatility : float
            Current volatility as a fraction (0–1).

        Returns
        -------
        Dict[str, float]
            A dictionary with keys ``action`` and ``confidence``.  The
            action is one of ``strong_sell``, ``sell``, ``hold``, ``buy``
            or ``strong_buy``.  Confidence is a float in [0, 1]
            indicating the membership degree of the crisp output in the
            chosen action's fuzzy set.
        """
        inputs = {
            "rsi": float(rsi),
            "macd_histogram": float(macd_histogram),
            "volatility": float(volatility),
        }
        crisp_output = self.system.evaluate(inputs)
        # Determine the action with highest membership degree at the crisp output
        memberships = {name: fs.membership(crisp_output) for name, fs in self.action.sets.items()}
        best_action = max(memberships.items(), key=lambda item: item[1])[0]
        confidence = memberships[best_action]
        return {"action": best_action, "confidence": confidence}


class TradingIndicators:
    """Convenience wrapper exposing indicator functions for trading.

    This class groups together the indicator functions defined in
    :mod:`fuzzy_analytics.indicators` for easier access in examples.
    All methods are static.
    """

    @staticmethod
    def calculate_rsi(prices: Iterable[float], period: int = 14) -> float:
        return calculate_rsi(prices, period)

    @staticmethod
    def calculate_macd(prices: Iterable[float], fast: int = 12, slow: int = 26, signal: int = 9) -> Tuple[float, float, float]:
        return calculate_macd(prices, fast, slow, signal)

    @staticmethod
    def calculate_volatility(prices: Iterable[float], period: int = 10) -> float:
        return calculate_volatility(prices, period)

    @staticmethod
    def calculate_bollinger_bands(prices: Iterable[float], window: int = 20, num_std: float = 2.0) -> Tuple[float, float, float]:
        return calculate_bollinger_bands(prices, window, num_std)
